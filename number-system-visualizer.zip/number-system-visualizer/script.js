/* =====================================================================
   PART 1: HELPER FUNCTIONS (plain loops and arithmetic, easy to explain)
   ===================================================================== */

// Digits used for bases up to 16 (hexadecimal needs A-F for 10-15)
var DIGITS = "0123456789ABCDEF";

/*
  HOW DIVISION-BY-2 WORKS
  -----------------------
  To convert a decimal number to binary:
    1. Divide the number by 2.
    2. Write down the remainder (it is always 0 or 1). This is one binary digit.
    3. Replace the number by the quotient (the whole-number part of the division).
    4. Repeat until the quotient becomes 0.
    5. Read the remainders from the LAST one to the FIRST one (bottom to top).
  The first remainder is the right-most bit (least significant bit).

  This function keeps every step in a list so we can show it in a table.
  It works for any base (2, 8, 16) by changing the divisor.
*/
function convertWithSteps(number, base) {
  var steps = [];
  var digits = "";

  if (number === 0) {                       // special case: 0 has no division steps
    return { text: "0", steps: [{ dividend: 0, quotient: 0, remainder: 0 }] };
  }

  while (number > 0) {
    var quotient  = Math.floor(number / base);  // whole-number part of the division
    var remainder = number % base;              // what is left over (modulo)
    steps.push({ dividend: number, quotient: quotient, remainder: remainder });
    digits = DIGITS.charAt(remainder) + digits; // put the new digit on the LEFT, so
                                                // the last remainder ends up first
    number = quotient;                          // continue with the quotient
  }
  return { text: digits, steps: steps };
}

// Add leading zeros so the string is exactly 'length' characters long
function padLeft(text, length) {
  while (text.length < length) {
    text = "0" + text;
  }
  return text;
}

/*
  HOW 1's COMPLEMENT IS DERIVED
  -----------------------------
  Take the binary pattern and flip every bit: each 0 becomes 1, each 1 becomes 0.
  Example: 00001101 -> 11110010
*/
function onesComplement(bits) {
  var result = "";
  for (var i = 0; i < bits.length; i++) {
    if (bits.charAt(i) === "0") {
      result = result + "1";
    } else {
      result = result + "0";
    }
  }
  return result;
}

/*
  HOW 2's COMPLEMENT IS CALCULATED
  --------------------------------
  2's complement = 1's complement + 1.
  We add 1 using school-style binary addition, going from the right-most bit
  to the left, carrying when 1 + 1 = 10 (write 0, carry 1).
  Example: 11110010 + 1 = 11110011
  Any carry that falls off the left end is discarded (we only keep 8 bits).
*/
function addOne(bits) {
  var result = "";
  var carry = 1;                              // the "+ 1" we want to add
  for (var i = bits.length - 1; i >= 0; i--) {  // right to left
    var bit = Number(bits.charAt(i));
    var sum = bit + carry;                    // 0, 1 or 2
    result = (sum % 2) + result;              // digit to write (2 -> 0)
    carry = Math.floor(sum / 2);              // carry to the next bit (2 -> 1)
  }
  return result;
}

/*
  Check: the value of an 8-bit signed pattern is
  (-128 x MSB) + (64 x b6) + (32 x b5) + ... + (1 x b0)
  We use this to verify our answer on screen.
*/
function signedValue(bits) {
  var value = 0;
  var weight = 128;
  for (var i = 0; i < bits.length; i++) {
    if (bits.charAt(i) === "1") {
      if (i === 0) { value = value - weight; }   // MSB has a negative weight
      else         { value = value + weight; }
    }
    weight = weight / 2;
  }
  return value;
}

// Turn a bit string into coloured boxes. The first bit (MSB) is the sign bit.
// 'extraClass' is used to mark bits that were flipped.
function bitsToHTML(bits, extraClass) {
  var html = '<div class="bits">';
  for (var i = 0; i < bits.length; i++) {
    var cls = "bit";
    if (i === 0) { cls += " sign"; }
    else if (extraClass) { cls += " " + extraClass; }
    html += '<span class="' + cls + '">' + bits.charAt(i) + '</span>';
  }
  return html + '</div>';
}

/*
  INPUT VALIDATION
  Accepts only whole numbers like 12, -12 or +12.
  Returns { ok: true, value: number }  or  { ok: false, message: "..." }
*/
function readInteger(text) {
  text = text.trim();
  if (text === "") {
    return { ok: false, message: "", empty: true };
  }
  if (!/^[+-]?[0-9]+$/.test(text)) {
    return { ok: false, message: "Please enter a whole number only (no decimals, letters or spaces)." };
  }
  return { ok: true, value: parseInt(text, 10) };
}

function showError(box, input, message) {
  if (message) {
    box.textContent = message;
    box.classList.remove("hidden");
    input.classList.add("invalid");
  } else {
    box.classList.add("hidden");
    input.classList.remove("invalid");
  }
}

/* =====================================================================
   PART 2: MODE A - MULTI-BASE CONVERTER
   ===================================================================== */
var decA = document.getElementById("decA");
var errA = document.getElementById("errA");

function updateModeA() {
  var tiles = document.getElementById("tilesA");
  var body  = document.getElementById("tableBody");
  var note  = document.getElementById("tableNote");
  var r = readInteger(decA.value);

  tiles.innerHTML = ""; body.innerHTML = ""; note.textContent = "";

  if (!r.ok) {
    showError(errA, decA, r.message);
    return;
  }
  // Keep numbers within the range JavaScript stores exactly
  if (Math.abs(r.value) > 9007199254740991) {
    showError(errA, decA, "That number is too large. Use a value up to 9,007,199,254,740,991.");
    return;
  }
  showError(errA, decA, "");

  var sign = r.value < 0 ? "-" : "";
  var magnitude = Math.abs(r.value);      // convert the positive part, then add the sign

  var bin = convertWithSteps(magnitude, 2);
  var oct = convertWithSteps(magnitude, 8);
  var hex = convertWithSteps(magnitude, 16);

  tiles.innerHTML =
    tile("Decimal (base 10)", r.value) +
    tile("Binary (base 2)", sign + bin.text) +
    tile("Octal (base 8)", sign + oct.text) +
    tile("Hexadecimal (base 16)", sign + hex.text);

  // Fill the division table
  for (var i = 0; i < bin.steps.length; i++) {
    var s = bin.steps[i];
    body.innerHTML += "<tr><td>" + (i + 1) + "</td><td>" + s.dividend + "</td><td>" +
                      s.quotient + "</td><td class='rem'>" + s.remainder + "</td></tr>";
  }
  note.textContent = "Read the Remainder column from bottom to top: " + bin.text +
    (sign ? " (the minus sign is added back at the end, since we converted " + magnitude + ")." : ".");
}

function tile(title, value) {
  return '<div class="tile"><small>' + title + '</small><div class="val">' + value + '</div></div>';
}

/* =====================================================================
   PART 3: MODE B - 8-BIT 1's AND 2's COMPLEMENT
   ===================================================================== */
var decB = document.getElementById("decB");
var errB = document.getElementById("errB");

function updateModeB() {
  var out = document.getElementById("stepsB");
  var r = readInteger(decB.value);
  out.innerHTML = "";

  if (!r.ok) {
    showError(errB, decB, r.message);
    return;
  }
  if (r.value < -128 || r.value > 127) {
    showError(errB, decB, r.value + " does not fit in 8 bits. Enter a value from -128 to +127.");
    return;
  }
  showError(errB, decB, "");

  var n = r.value;
  var magnitudeBits = padLeft(convertWithSteps(Math.abs(n), 2).text, 8);

  // ---- Positive numbers and zero: the 8-bit pattern is just the binary value ----
  if (n >= 0) {
    out.innerHTML =
      '<div class="step final"><h3>Positive number: direct 8-bit representation</h3>' +
      '<p>' + n + ' in binary, padded with zeros to 8 bits. The sign bit is 0.</p>' +
      bitsToHTML(magnitudeBits) +
      '<p>Check: ' + signedValue(magnitudeBits) + '</p></div>';
    return;
  }

  // ---- Negative numbers: 3 steps ----
  var ones = onesComplement(magnitudeBits);   // Step 2: flip all bits
  var twos = addOne(ones);                    // Step 3: add 1

  var extra = (n === -128)
    ? '<p>Note: -128 is the smallest value. Its magnitude 128 is 10000000, and the same pattern comes back after the complement steps.</p>'
    : '';

  out.innerHTML =
    '<div class="step"><h3>Step 1: Magnitude in 8-bit binary</h3>' +
    '<p>Ignore the minus sign. Write ' + Math.abs(n) + ' in binary using 8 bits.</p>' +
    bitsToHTML(magnitudeBits) + '</div>' +

    '<div class="step"><h3>Step 2: 1\'s complement</h3>' +
    '<p>Flip every bit: 0 becomes 1 and 1 becomes 0.</p>' +
    bitsToHTML(magnitudeBits) +
    bitsToHTML(ones, "flipped") + '</div>' +

    '<div class="step final"><h3>Step 3: 2\'s complement (final answer)</h3>' +
    '<p>Add 1 to the 1\'s complement: ' + ones + ' + 1 = ' + twos + '</p>' +
    bitsToHTML(twos) +
    '<p>The sign bit is <span class="tag">1</span>, so the number is negative. ' +
    'Check: -128 + (the remaining bits) = ' + signedValue(twos) + '</p>' +
    '<p>Hexadecimal: ' + padLeft(convertWithSteps(parseInt(twos, 2), 16).text, 2) + '</p></div>' +
    extra;
}

/* =====================================================================
   PART 4: TAB SWITCHING AND EVENTS
   ===================================================================== */
function showMode(mode) {
  var isA = (mode === "A");
  document.getElementById("modeA").classList.toggle("hidden", !isA);
  document.getElementById("outA").classList.toggle("hidden", !isA);
  document.getElementById("modeB").classList.toggle("hidden", isA);
  document.getElementById("outB").classList.toggle("hidden", isA);
  document.getElementById("tabA").setAttribute("aria-selected", isA);
  document.getElementById("tabB").setAttribute("aria-selected", !isA);
}

document.getElementById("tabA").addEventListener("click", function () { showMode("A"); });
document.getElementById("tabB").addEventListener("click", function () { showMode("B"); });
decA.addEventListener("input", updateModeA);   // update instantly while typing
decB.addEventListener("input", updateModeB);

// Show the default examples when the page loads
updateModeA();
updateModeB();
